import React, { useState } from "react";
import { motion } from "framer-motion";

const POKEMON = {
  psyduck: {
    name: "Psyduck",
    emoji: "🦆",
    title: "The Anxious Genius",
    desc: "You worry, you overthink, but you also arrive at surprising insights. People rely on your weirdly effective instincts.",
  },
  mrmime: {
    name: "Mr. Mime",
    emoji: "🎭",
    title: "The Meticulous Performer",
    desc: "You care about craft, timing, and presentation. You make order feel like art — and you enjoy the spotlight when it’s deserved.",
  },
  bulbasaur: {
    name: "Bulbasaur",
    emoji: "🌱",
    title: "The Loyal Realist",
    desc: "Calm, grounded, and steady — you’re the friend who stays. You grow through patience and make life feel safe for others.",
  },
  gengar: {
    name: "Gengar",
    emoji: "👻",
    title: "The Mischievous Charmer",
    desc: "Witty, a touch mysterious, and always a little rebellious. You entertain and unsettle in equal measure — in the best way.",
  },
  growlithe: {
    name: "Growlithe",
    emoji: "🔥",
    title: "The Loyal Protector",
    desc: "Brave with a big heart. You protect, cheer loudest, and are the first one to show up for people you care about.",
  },
  ditto: {
    name: "Ditto",
    emoji: "🧬",
    title: "The Adaptable Free Spirit",
    desc: "Fluid and curious — you adapt to your people and situations easily, and your flexibility makes you endlessly interesting.",
  },
};

const POKEMON_KEYS = [
  "psyduck",
  "mrmime",
  "bulbasaur",
  "gengar",
  "growlithe",
  "ditto",
];

const QUESTIONS = [
  {
    q: "You’re running late for an important meeting. What do you do?",
    opts: [
      "Panic a little, but somehow make it work last minute.",
      "Rehearse your excuse in your head — timing is everything.",
      "Take a deep breath. You’ll get there when you get there.",
      "Text a joke to lighten the mood — being late is your brand.",
      "Sprint there! You’re not letting anyone down.",
      "Blend in with the crowd and act like you’ve been there all along.",
    ],
  },
  {
    q: "Your friends describe you as:",
    opts: [
      "Constantly overthinking, but oddly wise.",
      "Precise and dramatic — in the best way.",
      "Chill, reliable, and surprisingly funny.",
      "Mysterious, sarcastic, and magnetic.",
      "Passionate and fiercely loyal.",
      "Adaptable — you can vibe with anyone.",
    ],
  },
  {
    q: "Your ideal weekend activity?",
    opts: [
      "Trying to relax… but somehow stressing anyway.",
      "Organizing your room until it’s museum-worthy.",
      "Gardening, hiking, or just chilling in nature.",
      "Late-night adventures with a bit of harmless chaos.",
      "Road trip with friends — windows down, music up.",
      "Doing whatever everyone else is doing — you’re just happy to be there.",
    ],
  },
  {
    q: "Your greatest strength is:",
    opts: [
      "Accidentally solving problems others can’t.",
      "Turning order into art.",
      "Staying grounded under pressure.",
      "Reading people like a book.",
      "Protecting and encouraging others.",
      "Blending into any situation with ease.",
    ],
  },
  {
    q: "When faced with conflict, you usually:",
    opts: [
      "Get overwhelmed but try to fix it anyway.",
      "Keep calm and analyze every word.",
      "Stay patient and mediate.",
      "Crack a joke and disappear if it gets too serious.",
      "Defend your friends without hesitation.",
      "Agree with everyone to keep the peace.",
    ],
  },
  {
    q: "Pick your favorite setting:",
    opts: [
      "A quiet lake where you can think.",
      "A tidy studio with perfect lighting.",
      "A lush forest full of calm and life.",
      "A dark alley glowing with neon mischief.",
      "A warm campfire surrounded by friends.",
      "A bustling city — endless faces, endless possibilities.",
    ],
  },
  {
    q: "How do you approach new challenges?",
    opts: [
      "Nervously, but you usually figure it out.",
      "With a plan, a backup plan, and a backup for that plan.",
      "Steadily — you know patience pays off.",
      "Boldly — you’ll fake confidence if you have to.",
      "Fearlessly — you charge in to protect and prove yourself.",
      "Casually — you’ll adapt as you go.",
    ],
  },
  {
    q: "Pick a motto that fits you best:",
    opts: [
      "“I’ll figure it out… eventually.”",
      "“Perfection is a performance.”",
      "“Slow and steady wins the race.”",
      "“Rules? I prefer guidelines.”",
      "“Loyalty above all.”",
      "“Go with the flow.”",
    ],
  },
  {
    q: "How do you show affection?",
    opts: [
      "Nervous laughter and small gestures.",
      "Thoughtful acts, never forgetting details.",
      "Steady support and genuine listening.",
      "Teasing and inside jokes.",
      "Big hugs and protective energy.",
      "Copying others’ quirks to make them smile.",
    ],
  },
  {
    q: "What kind of friend are you?",
    opts: [
      "The slightly chaotic but lovable one.",
      "The structured, reliable planner.",
      "The down-to-earth, comforting one.",
      "The funny, mysterious one who keeps everyone guessing.",
      "The fiercely loyal, courageous one.",
      "The flexible one who fits anywhere.",
    ],
  },
];

export default function App() {
  const [answers, setAnswers] = useState(Array(QUESTIONS.length).fill(null));
  const [finished, setFinished] = useState(false);
  const [result, setResult] = useState(null);

  function handleSelect(qIndex, optIndex) {
    const updated = [...answers];
    updated[qIndex] = POKEMON_KEYS[optIndex];
    setAnswers(updated);
  }

  function handleSubmit() {
    if (answers.includes(null)) {
      alert("Please answer all questions before seeing your Pokémon!");
      return;
    }
    const tally = {};
    POKEMON_KEYS.forEach((key) => (tally[key] = 0));
    answers.forEach((key) => tally[key]++);

    const topCount = Math.max(...Object.values(tally));
    const tied = Object.keys(tally).filter((k) => tally[k] === topCount);
    const chosen = tied[Math.floor(Math.random() * tied.length)];

    setResult(chosen);
    setFinished(true);
  }

  function restart() {
    setAnswers(Array(QUESTIONS.length).fill(null));
    setFinished(false);
    setResult(null);
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 flex items-center justify-center p-6">
      <div className="max-w-3xl w-full bg-white rounded-2xl shadow-xl p-8 grid gap-6">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-extrabold">
              Which Pokémon Are You?
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Answer all questions to reveal your Pokémon type.
            </p>
          </div>
          <div className="text-right text-sm text-slate-600">
            <div>
              Progress{" "}
              <strong>{answers.filter((a) => a !== null).length}</strong> /{" "}
              {QUESTIONS.length}
            </div>
          </div>
        </header>

        {!finished ? (
          <div className="space-y-8">
            {QUESTIONS.map((q, qIndex) => (
              <motion.div
                key={qIndex}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.2 }}
              >
                <h2 className="text-lg font-semibold mb-3">{q.q}</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {q.opts.map((opt, optIndex) => (
                    <button
                      key={optIndex}
                      onClick={() => handleSelect(qIndex, optIndex)}
                      className={`rounded-xl p-4 border transition text-left ${
                        answers[qIndex] === POKEMON_KEYS[optIndex]
                          ? "border-indigo-500 bg-indigo-50"
                          : "border-slate-200 hover:border-indigo-300"
                      }`}
                    >
                      <span className="text-sm text-slate-700">{opt}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            ))}
            <div className="flex justify-center pt-4">
              <button
                onClick={handleSubmit}
                className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-pink-600 text-white shadow-md hover:opacity-90"
              >
                Reveal My Pokémon!
              </button>
            </div>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="text-center py-6"
          >
            <div className="inline-flex items-center justify-center w-28 h-28 rounded-full bg-gradient-to-br from-indigo-100 to-pink-100 text-5xl mb-4">
              {POKEMON[result].emoji}
            </div>
            <h3 className="text-2xl font-bold">
              You are {POKEMON[result].name} — {POKEMON[result].title}
            </h3>
            <p className="mt-3 text-slate-600 max-w-xl mx-auto">
              {POKEMON[result].desc}
            </p>
            <div className="mt-6">
              <button
                onClick={restart}
                className="px-5 py-2 rounded-lg bg-gradient-to-r from-indigo-600 to-pink-600 text-white shadow"
              >
                Retake quiz
              </button>
            </div>
            <div className="mt-4 text-xs text-slate-400">
              If there was a tie, your Pokémon was chosen randomly from the top
              matches.
            </div>
          </motion.div>
        )}
        <footer className="text-xs text-slate-400 text-center pt-6">
          Built with ❤️ · Tailwind + React + Framer Motion
        </footer>
      </div>
    </div>
  );
}
